<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Pengunjung</title>
    <style>
        body { font-family: sans-serif; padding: 20px; }
        form { max-width: 400px; margin: 0 auto; }
        label { display: block; margin-top: 10px; }
        input, select { width: 100%; padding: 8px; margin-top: 5px; }
        button { margin-top: 20px; padding: 10px 20px; cursor: pointer; }
        .back { margin-top: 10px; display: inline-block; }
    </style>
</head>
<body>
    <h2 style="text-align: center;">Tambah Data Pengunjung</h2>
    
    <form action="proses_tambah.php" method="POST">
        <label>Nama Pengunjung</label>
        <input type="text" name="nama" required>

        <label>Kelas</label>
        <select name="kelas" required>
            <option value="">-- Pilih Kelas --</option>
            <option value="X">Kelas X</option>
            <option value="XI">Kelas XI</option>
            <option value="XII">Kelas XII</option>
            <option value="Guru/Staff">Guru/Staff</option>
            <option value="Umum">Umum</option>
        </select>

        <label>Tujuan</label>
        <input type="text" name="tujuan" placeholder="Contoh: Baca Buku, Peminjaman..." required>

        <button type="submit" name="simpan">Simpan Data</button>
    </form>

    <center>
        <a href="index.php" class="back">Kembali ke Beranda</a>
    </center>
</body>
</html>