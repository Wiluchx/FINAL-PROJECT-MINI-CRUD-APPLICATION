<?php
include 'koneksi.php';

// Ambil data berdasarkan ID
 $id = $_GET['id'];
 $query = mysqli_query($koneksi, "SELECT * FROM pengunjung WHERE id = '$id'");
 $data = mysqli_fetch_array($query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Data</title>
    <style>
        body { font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; background: #f4f6f9; }
        .card { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); width: 100%; max-width: 400px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        .btn { width: 100%; padding: 10px; border: none; cursor: pointer; border-radius: 4px; color: white; margin-top: 10px; }
        .btn-primary { background: #007bff; }
        .btn-secondary { background: #6c757d; margin-top: 5px; text-decoration: none; display: block; text-align: center; }
    </style>
</head>
<body>

<div class="card">
    <h2>Edit Data</h2>
    <form action="proses_edit.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $data['id']; ?>">
        
        <div class="form-group">
            <label>Nama</label>
            <input type="text" name="nama" value="<?php echo $data['nama']; ?>" required>
        </div>
        <div class="form-group">
            <label>Kelas</label>
            <select name="kelas" required>
                <option value="X" <?php if($data['kelas']=='X') echo 'selected'; ?>>Kelas X</option>
                <option value="XI" <?php if($data['kelas']=='XI') echo 'selected'; ?>>Kelas XI</option>
                <option value="XII" <?php if($data['kelas']=='XII') echo 'selected'; ?>>Kelas XII</option>
                <option value="Guru/Staff" <?php if($data['kelas']=='Guru/Staff') echo 'selected'; ?>>Guru/Staff</option>
                <option value="Umum" <?php if($data['kelas']=='Umum') echo 'selected'; ?>>Umum</option>
            </select>
        </div>
        <div class="form-group">
            <label>Tujuan</label>
            <input type="text" name="tujuan" value="<?php echo $data['tujuan']; ?>" required>
        </div>

        <button type="submit" name="update" class="btn btn-primary">Update Data</button>
    </form>
    <a href="index.php" class="btn btn-secondary">Kembali</a>
</div>

</body>
</html>