<?php
include 'koneksi.php';

if(isset($_POST['update'])){
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $kelas = $_POST['kelas'];
    $tujuan = $_POST['tujuan'];

    $query = mysqli_query($koneksi, "UPDATE pengunjung SET nama='$nama', kelas='$kelas', tujuan='$tujuan' WHERE id='$id'");

    if($query){
        header("Location: index.php");
    } else {
        echo "Gagal: " . mysqli_error($koneksi);
    }
}
?>