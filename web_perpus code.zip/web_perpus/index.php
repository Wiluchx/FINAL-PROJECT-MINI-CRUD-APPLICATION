<?php
include 'koneksi.php';

// LOGIKA PENCARIAN
 $query = "SELECT * FROM pengunjung ORDER BY id DESC";
if(isset($_GET['cari'])){
    $keyword = $_GET['cari'];
    $query = "SELECT * FROM pengunjung WHERE nama LIKE '%$keyword%' OR kelas LIKE '%$keyword%' ORDER BY id DESC";
}
 $result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log perpus</title>
    
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="container">
    <!-- Header tanpa tombol tambah -->
    <div class="header-section">
        <h2>📚 Log Pengunjung perpustkaan sekolah</h2>
    </div>

    <!-- Pencarian -->
    <form action="" method="GET" class="search-box">
        <input type="text" name="cari" class="search-input" placeholder="Cari nama pengunjung atau kelas..." value="<?php echo isset($_GET['cari']) ? $_GET['cari'] : ''; ?>">
        <button type="submit" class="btn btn-primary">Cari</button>
        <a href="index.php" class="btn btn-warning">Reset</a>
    </form>

    <!-- Tabel Data -->
    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th width="5%">No</th>
                    <th width="30%">Nama Pengunjung</th>
                    <th width="15%">Kelas</th>
                    <th width="25%">Tujuan</th>
                    <th width="15%">Waktu</th>
                    <th width="10%">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $no = 1;
                if(mysqli_num_rows($result) > 0){
                    while($row = mysqli_fetch_array($result)){
                ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><strong><?php echo $row['nama']; ?></strong></td>
                    <td><span class="badge-kelas"><?php echo $row['kelas']; ?></span></td>
                    <td><?php echo $row['tujuan']; ?></td>
                    <td style="font-size:0.85rem; color:#888;"><?php echo date('d M Y, H:i', strtotime($row['tanggal'])); ?></td>
                    <td>
                        <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-warning" style="padding:6px 12px; font-size:12px;">Edit</a>
                        <a href="hapus.php?id=<?php echo $row['id']; ?>" class="btn btn-danger" style="padding:6px 12px; font-size:12px;" onclick="return confirm('Yakin hapus data ini?')">Hapus</a>
                    </td>
                </tr>
                <?php }
                } else { ?>
                <tr><td colspan="6" style="text-align:center; padding:30px; color:#aaa;">Data tidak ditemukan.</td></tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<!-- FLOATING ACTION BUTTON (Tombol Melayang) -->
<!-- ID tetap btnOpenModal agar JS tetap jalan -->
<div id="btnOpenModal" class="fab" title="Tambah Data">+</div>

<!-- MODAL TAMBAH DATA -->
<div id="modalTambah" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Tambah Pengunjung</h3>
            <span class="close">&times;</span>
        </div>
        
        <form action="proses_tambah.php" method="POST">
            <div class="form-group">
                <label>Nama Lengkap</label>
                <input type="text" name="nama" class="form-control" placeholder="Masukkan nama..." required>
            </div>
            <div class="form-group">
                <label>Kelas</label>
                <select name="kelas" class="form-control" required>
                    <option value="">-- Pilih Status --</option>
                    <option value="X">Kelas X</option>
                    <option value="XI">Kelas XI</option>
                    <option value="XII">Kelas XII</option>
                    <option value="Guru/Staff">Guru / Staff</option>
                    <option value="Umum">Umum</option>
                </select>
            </div>
            <div class="form-group">
                <label>Tujuan Kunjungan</label>
                <input type="text" name="tujuan" class="form-control" placeholder="Contoh: Membaca, Peminjaman..." required>
            </div>
            <button type="submit" name="simpan" class="btn btn-primary" style="width:100%;">Simpan Data</button>
        </form>
    </div>
</div>

<script src="js/script.js"></script>

</body>
</html>