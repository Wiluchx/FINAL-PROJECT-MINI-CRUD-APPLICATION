<?php
include 'koneksi.php';

if(isset($_POST['simpan'])){
    $nama = $_POST['nama'];
    $kelas = $_POST['kelas'];
    $tujuan = $_POST['tujuan'];

    $query = mysqli_query($koneksi, "INSERT INTO pengunjung (nama, kelas, tujuan) VALUES ('$nama', '$kelas', '$tujuan')");

    if($query){
        header("Location: index.php");
    } else {
        echo "Gagal: " . mysqli_error($koneksi);
    }
}
?>