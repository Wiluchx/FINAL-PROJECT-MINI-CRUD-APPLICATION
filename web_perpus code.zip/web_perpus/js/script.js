// Ambil elemen modal dan tombol
const modal = document.getElementById('modalTambah');
const btnOpen = document.getElementById('btnOpenModal');
const btnClose = document.querySelector('.close');

// 1. Buka Modal
if(btnOpen) {
    btnOpen.onclick = function() {
        modal.style.display = "flex";
    }
}

// 2. Tutup Modal (Tombol X)
if(btnClose) {
    btnClose.onclick = function() {
        modal.style.display = "none";
    }
}

// 3. Tutup Modal jika klik di luar
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}