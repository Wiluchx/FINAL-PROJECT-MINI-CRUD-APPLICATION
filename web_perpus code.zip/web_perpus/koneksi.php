<?php
 $koneksi = mysqli_connect("localhost", "root", "", "db_perpus");

if (mysqli_connect_errno()) {
    echo "Gagal koneksi ke Database: " . mysqli_connect_error();
}
?>